package p03WildFarm;

public class Vegetable extends Food {

    public Vegetable() {
        super();
    }

    public Vegetable(Integer foodQuantity) {
        super(foodQuantity);
    }

}
