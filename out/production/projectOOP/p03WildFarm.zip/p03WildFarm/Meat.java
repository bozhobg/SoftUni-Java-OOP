package p03WildFarm;

public class Meat extends Food {

    public Meat() {
        super();
    }

    public Meat(Integer foodQuantity) {
        super(foodQuantity);
    }

}
